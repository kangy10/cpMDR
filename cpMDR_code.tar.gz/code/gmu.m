%This function is for estimating the ditribution of shift function
%pij is the  non-null proportion
%lam is the bandwidth parameter 
%Xj is the sample data
% u and sigma is the known or estimated parameters of null distribution
function [Hmu]=gmu(pij,lam,Xj,mu,sigma)
  Time=linspace(-1/lam ,1/lam,100);
  result=0;
 for t=1:(length(Time)-1)
    result=result+mean(cos(Time(t)*(mu-Xj)))*exp(0.5*sigma^2*Time(t)^2)/lam/50;
 end
 result=result-2*(1-pij)*sin(mu/lam)/mu;
  result=result/(2*pi*pij);
  Hmu=max(result,0);
end

