function [lr li]=llrlli(P,li1,li2,lr1,lr2,eps1,m,n,L1k,Lnk,Lkj,Ljk,L0j,Ljnk,B,B0,k,alpha_I,alpha_r)
lli=linspace(li1,li2,100);
llr=linspace(lr1,lr2,200);
l1=length(lli);l2=length(llr);BLR=[];A=[];
 for i=1:l1
     li=lli(i);  
    for j=1:l2
     lr=llr(j);
            dell=[];
            for h=1:m
               ind=h;
                BB01=lr*L1k(ind)+li*Lnk(ind)-li*alpha_I*Lnk(ind);
                BB1=Lkj(:,ind)+li*Ljk(:,ind)+L0j(:,ind)-lr*alpha_r*L1k(ind);%
                b=[BB1' BB01];[min_b,index]=min(b,[],2) ; 
               if (index==n+1) index=0; end
                dell(h)=index;
            end
              del1=dell';     
      [mdri_e mdrr_e efp_e]=mdr_e(P,n,del0,B,B0,k,Lnk,L1k);
      A=[lr li mdrr_e mdri_e efp_e]; 
      BLR=[A;BLR];   
    end
 end 
 CC=intersect(find(BLR(:,3)<alpha_r+eps1),find(BLR(:,3)>alpha_r-eps1));
 CD=intersect(find(BLR(:,4)<alpha_I+eps1),find(BLR(:,4)>alpha_I-eps1));
 C11=BLR(intersect(CC,CD),:);
 abmin=abs(C11(:,3)-alpha_r)+abs(C11(:,4)-alpha_I);
 [abm index]=min(abmin,[],1);fina=C11(index,:);
 lr=fina(:,1);li=fina(:,2);
  end
  



