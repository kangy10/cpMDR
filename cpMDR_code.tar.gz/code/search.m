 function [lr1,lr2,li1,li2]=search(P,m,n,k,res1,res2,lii1,lii2,lrr1,lrr2,alpha_r,alpha_I,L1k,Lnk,Lkj,Ljk,L0j,Ljnk,B,B0)
 lli=linspace(lii1,lii2,50);
 llr=linspace(lrr1,lrr2,50);
     l1=length(lli);
     l2=length(llr);
     BLR=[];A=[];
 for i=1:l1
     li=lli(i);  
   for j=1:l2
     lr=llr(j);
     dell=[];
            for h=1:m
               ind=h;
                BB01=lr*L1k(ind)+li*Lnk(ind)-li*alpha_I*Lnk(ind);
                BB1=Lkj(:,ind)+li*Ljk(:,ind)+L0j(:,ind)-lr*alpha_r*L1k(ind);%
                b=[BB1' BB01];[min_b,index]=min(b,[],2) ; 
               if (index==n+1) index=0; end
                dell(h)=index;
            end
              del1=dell';     
     [mdri_e mdrr_e efp_e]=mdr_e(P,n,del0,B,B0,k,Lnk,L1k);
     del=del1;
     A=[lr li mdrr_e mdri_e efp_e]; 
     BLR=[A;BLR];   
    end
 end

 CC=intersect(find(BLR(:,3)<alpha_r+res1),find(BLR(:,3)>alpha_r-res1));
 CD=intersect(find(BLR(:,4)<alpha_I+res2),find(BLR(:,4)>alpha_I-res2));
 C11=BLR(intersect(CC,CD),:);
 lr1=min(C11(:,1));lr2=max(C11(:,1));
 li1=min(C11(:,2));li2=max(C11(:,2));
 end
 