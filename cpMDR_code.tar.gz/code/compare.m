function  [del0 lam]=compare(P,lam1,lam2,eps2,m,n,alpha_0,alpha_I,B,B0,L1k,Lnk,Lkj,Ljk,L0j,Ljnk,p0,g,gg,X,k)
lamm=linspace(lam1,lam2,10000);kk=length(lamm);
A=[];BLI=[];del0=[];
for l=1:kk
    lam=lamm(l);
    del0=[];
                 for i=1:m
                    ind=i;
                    B01=lam*Lnk(ind)-lam*alpha_0*Lnk(ind);
                    BB1=Lkj(:,ind)+lam*Ljk(:,ind)+L0j(:,ind);%
                    b=[BB1' B01];
                    [min_b,index]=min(b,[],2) ; 
                   if(index==n+1)
                    index=0;
                   end
                   del0(i)=index;  
                end
   del0=del0';
   p00=1-sum(P);
  [mdri_e mdrr_e efp_e]=mdr_e(P,n,del0,B,B0,k,Lnk,L1k);
  A=[lam mdrr_e mdri_e efp_e];      
  BLI=[A;BLI];    
end

 CCI=intersect(find(BLI(:,3)<alpha_0+eps2),find(BLI(:,3)>alpha_0-eps2));
 C11=BLI(CCI,:);
 abmin=abs(C11(:,3)-alpha_0);
 [abm index1]=min(abmin,[],1);
 fina=C11(index1,:);
 lam=fina(:,1);

del0=[];
     for i=1:m
        ind=i;
        B01=lam*Lnk(ind)-lam*alpha_0*Lnk(ind);
        BB1=Lkj(:,ind)+lam*Ljk(:,ind)+L0j(:,ind);%
        b=[BB1' B01];
        [min_b,index]=min(b,[],2) ; 
       if(index==n+1)
        index=0;
       end
     del0(i)=index;  
    end
       del0=del0';
    
end
    







    
