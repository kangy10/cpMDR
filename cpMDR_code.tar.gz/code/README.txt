** This is a README file containing the list of online supplements related to the paper titled "A Unified Framework for High-Dimensional Data Stream Analysis in Fault Diagnosis" **


Below are main functions used:

1. Bdata.m       generate date according to case settings
2. compare.m       search for 'lambda_I' and obtain decision with only MDR_1 controlled
3. search.m        pre-search for 'l1' and 'l2' when two MDRs are controlled
4. llrlli.m        search for 'l1' and 'l2'
5. gmu.m          eatimate 'hmu' in data-driven procedure
6. PEST_dir.m      estimate 'p0' in data-driven procedure
