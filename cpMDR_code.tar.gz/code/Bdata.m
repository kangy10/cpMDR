%This function is for generate data and regular computation from data
%pp1 is the proportion defined in Case II as "r5" in article, pp2=1-pp1;
%pp1 is the number relative to "r5*n", np2=n-np1;
%m is the number of datastream; n is the number of points in each datastream
%s is the standard variance of data, p0 is the non-null proportion
%A1,B1,C1 is the parameter of gamma distribution, with relative to location size, shift size and constant
function [B B0 g X gg L1k Lnk Lkj Ljk L0j Ljnk k theta P]=Bdata(pp1,pp2,np1,np2,m,n,s,p0,A1,B1,C1)
theta=binornd(1,1-p0,m,1);
x1=linspace(1,fix(n*np1),fix(n*np1)); 
A=linspace(1,n,n);x2=setdiff(A,x1); 

rr1=repmat(1/(n*np1),(n*np1),1)';  
rr2=repmat(1/(n*np2),(n*np2),1)';

r1=randsrc(fix(m*pp1),1,[x1;rr1]);
r2=randsrc(m-fix(m*pp1),1,[x2;rr2]);
r=[r1',r2'];k=r'.*theta;

P=zeros(1,n);P(1,x1)=(1-p0)*pp1/(n*np1);P(1,x2)=(1-p0)*pp2/(n*np2);

sigma=s;
MU=zeros(m,n);
    for i=1:m
        if theta(i)==1
            ind=k(i);
			MU(i,ind:n)=gamrnd(A1,B1)+C1;
        end
    end  

 X=[];
  for i=1:m
      for j=1:n
          X(i,j)=normrnd(0,sigma,1,1);  
      end
  end
  X=X+MU;

gg=normpdf(X,0,1); g0=mean(gg'); g0=g0';
MU1=linspace(-C1,20-C1,600);
g=[];
for i=1:m
    for j=1:n
       sigma=s^(abs(i-j));
       g(i,j)=sum(normpdf(X(i,j),MU1,sigma).*gampdf(MU1,A1,B1))/(600/20);
    end
end          

B0=[];B=[];
for i=1:m
  for j=1:n
        B(i,j)=P(j)*g(i,j)/(sum(P(j)*g(i,:))+p0*gg(i,j));
    end
end

for i=1:m
     B0(i)=1-sum(B(i,:));
end

L1k=[];
for i=1:m
       L1k(i)=sum(B(i,:));
end
L1k=L1k';

Lkj=[];Ljk=[];
for l=linspace(1,n,n)
  for i=1:m 
      t1=0;t2=0;
      for j=1:l-1
          t1=t1+(l-j)*B(i,j);
      end
      for j=l+1:n
          t2=t2+(j-l)*B(i,j);
      end
      Ljk(l,i)=t1;
      Lkj(l,i)=t2;
  end
end
  Lkj=Lkj; Ljk=Ljk;
 
  
 Lnk=[];
 for i=1:m
     for j=1:n
         LL(i,j)=(n+1-j)*B(i,j);
     end
     Lnk(i)=sum(LL(i,:));
 end
     Lnj=Lnk';  
     
     
     L0j=[];
    for l=linspace(1,n,n)
         for i=1:m
             L0j(l,i)=(n+1-l)*B0(i);
         end
     end
    
     
 Ljnk=[];
 for l=linspace(1,n,n)
   for i=1:m
       t3=0;
     for j=1:l-1
        t3=t3+(n+1-j)*B(i,j);
     end
       Ljnk(l,i)=t3;
    end
 end     
 Ljnk=Ljnk;
end






        
